# HDPrintX — Full Interface Atlas and Codex Implementation Blueprint

**Version:** 2.0  
**Business name:** HDPrintX  
**Owned domain:** `hdprintx.in`  
**Architecture already selected:** Next.js/React frontend, Spring Boot (Java), PostgreSQL, separate DEV/QA, single budget VPS for PROD.  
**DEV preview:** protected Cloudflare Tunnel after Cloudflare Access is configured.  
**Asset source:** `HDPrintX_Complete_Experience` prototype directory.

## 0. Critical instruction for Codex

**DO NOT REPLACE OR DESTROY THE EXISTING PROJECT.** There have been substantial changes in the active Codex repository since the original Phase 0 scaffold. Inspect the current code, routes, components, authentication, APIs, production models, DB migrations, tests, environment and deployment configuration first. Treat this visual prototype as a **design reference**, not a source of business truth. Reconcile each screen against the code actually present before implementation.

The HTML/JS prototype has 88 views; all data and actions are fictional, except local UX simulations. Screens marked by a working demonstration DO NOT prove backend feature completion. Keep unknowns documented and do not fabricate working production functionality.

## 1. Design goals

1. **Public site:** distinct, premium, editorial, animated visual language inspired by creative-agency storytelling, tactile product demos and warm print-process photography.
2. **Customer portal:** minimal steps to request a quote, review proof, approve/version artwork, message the company, pay and track jobs.
3. **Owner/MIS:** information-dense, accessible operational software for leads, quotes, order, production, inventory, finance, vendors and reporting.
4. **Press room:** quick large touch targets, short job tickets, QR references, stage progress, quantity, waste and defect logging.
5. **Vendor:** only explicitly assigned outsourced work; do not reveal customer selling prices or unrelated assets.
6. **Delivery:** route assignment, dispatch details, partial deliveries, proof of delivery.
7. **Shared standards:** WCAG 2.2 AA target, responsive forms, keyboard accessibility, reduced-motion support, persisted audit trails, loading/empty/error/permitted states.

**Visual tokens in the demonstration:** navy `#0b1428`, primary blue `#426dff`, coral `#ffb99b`, paper `#f7f7f3`, text `#121b2c`, green `#19855b`, critical `#ce453f`. These are **candidates**, not irrevocable brand guidelines. Prioritise the real HDPrintX logo and any existing approved brand system.

## 2. Screen catalog

The authoritative machine-readable inventory is `VIEW_INVENTORY.csv` and `VIEW_INVENTORY.json`. All prototypes can be opened by URL fragment (`index.html#<id>`). There are **88 different screen entries in seven groups**. Some screen entries intentionally share interface components (tables, details, forms) but contain role-specific content.

### Screen coverage by group

| Workspace | Screens | Public/private |
|---|---:|---|
| Public website | 15 | Public |
| Customer portal | 19 | Customer-only except sign-in |
| Owner & management | 34 | Role-based internal |
| Production floor | 7 | Worker permissions |
| Vendor collaboration | 4 | Scoped external vendors |
| Delivery staff | 3 | Scoped delivery staff |
| System & UX states | 6 | Internal QA/design |
| **Total** | **88** | |

### Required states for EVERY route

- Loading/skeleton state and helpful pending indicator
- Empty data state with correct recovery affordance
- Error state with safe retry
- Permission denied / logged-out state
- Network interruption where relevant
- Mobile layout and touch targets
- Keyboard focus and tab order
- Reduced motion alternative
- Success / in-progress / failure notification states
- Pagination/search/filter where relevant

## 3. Navigation and route groups

Build an explicit role-aware router. Example **proposed routes** (reconcile with current Next.js routes):

```text
/                         public home
/products                 catalog
/products/[slug]          product detail
/materials                finish explorer
/our-work                 portfolio
/our-work/[slug]          case study
/process                  process storytelling
/about                    company story
/contact                  contact and enquiry
/quote                    guest/customer quote builder

/account                  customer home
/account/quotes            list of quotes
/account/quotes/[id]       quote detail/revisions
/account/orders            customer order list
/account/orders/[id]       order workspace & tracking
/account/orders/[id]/artwork  artwork version + proof review
/account/messages          order-linked conversation
/account/payments          payments and invoices
/account/settings          business profile and addresses

/business                 owner overview
/business/leads           enquiries and pipeline
/business/quotes          quotes and costing
/business/orders          order management
/business/orders/[id]     order workspace
/business/production      live job board
/business/schedule        press planning
/business/inventory       paper, ink, plates and consumables
/business/procurement     purchase orders and suppliers
/business/vendors         subcontracts and vendor handoffs
/business/dispatch        dispatch and proof of delivery
/business/finance         payments and receivables
/business/analytics       reports and financial/production health
/business/staff           teams, tasks and access control
/business/integrations    mail, WhatsApp, phone, social, payment settings

/floor                    press room task queue
/floor/jobs/[id]          printable/QR job ticket
/floor/run/[id]           run and waste logger
/floor/qc/[id]            QC checklist

/vendor                   vendor-only queue
/vendor/jobs/[id]         assigned work + authorised files
/driver                   driver schedule
/driver/deliveries/[id]   proof of delivery
```

Do **not** expose fake `/business` authentication as if it were secure. Enforce authorization server-side and validate identifiers on every API call.

## 4. Main screen flows

### 4.1 Lead → quote → order → delivery

```mermaid
flowchart TD
    A[Website / Walk-in / Phone / WhatsApp / Social] --> B[Lead and CRM]
    B --> C[Structured print requirements]
    C --> D[Owner reviewed quotation vN]
    D --> E{Accepted?}
    E -- Change requested --> D
    E -- Accepted --> F[Artwork and preflight]
    F --> G{Exact proof vN approved?}
    G -- Revisions --> F
    G -- Yes --> H{Release conditions met?}
    H -- No --> I[Await deposit / stock / authorisation]
    I --> H
    H -- Yes --> J[Production job ticket]
    J --> K[Press / Finishing / QC]
    K --> L[Partial/full dispatch]
    L --> M[Delivery verification]
    M --> N[Balance collection / feedback / reorder]
```

### 4.2 Production and subcontracts

```mermaid
flowchart LR
    A[Approved Order Item] --> B[Production Route]
    B --> C[Prepress]
    C --> D[Press]
    D --> E[Finishing]
    E --> F[QC]
    F --> G[Dispatch]
    E --> H{Outsource required?}
    H -- Yes --> I[Scoped vendor work package]
    I --> J[Vendor accepts & reports]
    J --> K[Goods or files returned]
    K --> F
```

### 4.3 Integration events and retry safety

```mermaid
flowchart TD
    A[Signed provider webhook / email pull / manual entry] --> B[Verify source & permissions]
    B --> C[Normalise and deduplicate event]
    C --> D[Match customer and order]
    D --> E[Persist in Postgres with audit]
    E --> F[Outbox event]
    F --> G[Retry worker]
    G --> H{Delivery succeeded?}
    H -- No --> I[Backoff, dead-letter and staff alert]
    H -- Yes --> J[Record provider acknowledgement]
```

## 5. UI component implementation map

Create a shared component library, but separate the public marketing layout from dense operational applications. Use current project component conventions where possible.

| Component family | Reused by |
|---|---|
| BrandHeader / PublicNav / PublicFooter | Home, product pages, portfolio, process, contact |
| ProductCard / ProductFilter / ProductMedia | Product listing, product detail, quick quote, reorder |
| FinishSwitcher / MaterialPreview | Material Lab, product detail, quote configurator |
| QuoteStepper / QuoteForm / QuoteSummary | Quote entry, draft, quote review, estimate editor |
| AssetUploader / PreflightReport | Customer uploads, internal prepress, vendor deliverables |
| ProofViewer / VersionSelector / AnnotationLayer | Customer proof approval, internal artwork queue |
| StatusTimeline / OrderActivity | Orders list/detail, tracking, owner workspace |
| ConversationInbox / MessageComposer | Customer inbox, owner unified inbox, vendor communication |
| KPI / StatusPill / DataTable / FilterBar | Owner dashboard, CRM, inventory, finance, jobs |
| ScheduleGrid / KanbanLane / JobCard | Staff, production scheduler, machine board |
| MaterialReservation / StockMovement | Inventory, job ticket, procurement |
| VendorWorkPackage / ScopeGuard | Outsourcing, vendor dashboard, vendor files |
| InvoiceCard / Ledger / PaymentRecord | Customer payments, owner finance, receivables |
| EmptyState / ErrorState / LoadingState / PermissionDenied | **Every route** |

## 6. Application and data architecture

```mermaid
flowchart TD
    A[Next.js Public Site] --> API[Spring Boot API]
    B[Customer PWA] --> API
    C[Business Admin] --> API
    D[Floor / Vendor / Driver] --> API
    API --> CRM[CRM + Quotes + Orders]
    API --> OPS[Production + Inventory]
    API --> FIN[Billing + Delivery]
    API --> COL[Permissions + Messaging + Audit]
    CRM --> PG[(PostgreSQL)]
    OPS --> PG
    FIN --> PG
    COL --> PG
    API --> STO[Private file storage]
    API --> OUT[Outbox + background jobs]
    OUT --> PDF[Python PDF preflight]
    OUT --> EXT[Email / WhatsApp / Payments / Social]
```

Recommended entities: `Customer`, `CustomerContact`, `Enquiry`, `PrintProduct`, `PrintSpecification`, `Quote`, `QuoteVersion`, `Order`, `OrderItem`, `ArtworkVersion`, `ProofDecision`, `ProductionJob`, `ProductionOperation`, `Machine`, `MaterialSKU`, `StockMovement`, `MaterialReservation`, `PurchaseOrder`, `Vendor`, `SubcontractWorkPackage`, `Invoice`, `Payment`, `Delivery`, `OrderEvent`, `Communication`, `Employee`, `Role`, `Permission`, `AuditEvent`.

**Important:** one order can have multiple line items; line items can have multiple production operations and split deliveries. Approval references a specific immutable file/checksum and quote version. Quotation acceptance never mutates old versions. State transitions must be authorised and validated.

## 7. API integration policy

1. Audit existing Spring Boot controllers and typed DTOs; don't invent endpoints that conflict with existing code.
2. Implement the design screens behind typed API client adapters.
3. Provide mock data providers only for Storybook/QA environments; **no mock fallbacks on production business actions**.
4. All order, proof, payment and production mutations go through authenticated APIs with transactions, audit records and optimistic concurrency or locking as necessary.
5. For payments verify server-side gateway webhook signatures and idempotency; never mark paid based on frontend redirects.
6. Inbound external messages require verified provider webhook handling; use official APIs and respect consent/template windows.
7. Use private file storage, antivirus / scanning, checked file types and short-lived signed URLs for artwork.
8. Avoid real-time 'live camera' labels unless actual, authorised telemetry/video is present. Render truthful staff-confirmed status instead.

## 8. Animation rules

- Homepage: floating print sample, parallax *only when appropriate*, striking editorial transitions, lightweight assets.
- Material Lab: switch finish / sheen with accessible controls and static fallback; do not imply physical or colour accuracy.
- Quote: instant local field validation and clearly labelled **indicative** pricing only where the estimating engine is configured.
- Order tracking: animate between **actual** stored status events; avoid fabricated progress bars.
- Admin/production: subtle purposeful updates, no scroll hijacking or cinematic delays.
- Honour `prefers-reduced-motion`, keyboard navigation and mobile GPU constraints.
- Choose CSS/Motion for most UI; import Three.js lazily only for a specific valuable product preview.

## 9. Development rollout

| Stage | What to implement | Gate |
|---|---|---|
| A. Audit | Current repo, routes, database, files, deployments | Document existing vs proposed screens |
| B. Foundation | Tokens, typography, shared components, responsive shell | UI review, accessibility baseline, no regressions |
| C. Public site | Homepage, products, portfolio, process, contact | Lighthouse / mobile / lead capture testing |
| D. Customer workflows | Quotes, artwork, proof, timeline, customer dashboard | E2E lead-to-approved order pilot |
| E. Owner CRM | Inbox, pipeline, quotes, order workspace | Accurate role authorization and audit |
| F. Production | Machine planning, job tickets, paper, QC | Shop-floor UAT on real-size orders |
| G. Vendors / delivery | Scoped subcontracts, dispatch, POD | Security isolation and partial-job tests |
| H. Finance / integrations | Invoicing, reconciliation, messaging, social | Provider sandbox and negative-case testing |
| I. Analytics / polish | Correct data metrics, motion, mobile/empty/error | Quality/security/performance release gates |

Work in small mergeable PRs; do not redesign all 88 routes and change business logic in one Codex task.

## 10. DEV/QA/PROD and domain

- **DEV:** Windows laptop with Docker Compose and isolated sample data.
- **DEV remote preview:** named Cloudflare Tunnel to `dev.hdprintx.in`, **Cloudflare Access** restricted to approved testers. Tunnel running only when the dev machine is on.
- **QA:** separate local Docker environment, separate credentials/database and anonymised/synthetic dataset; `qa.hdprintx.in` protected via Access if externally previewed.
- **PROD:** one independent VPS (Hostinger KVM 2 is the current budget preference), production-grade authentication, HTTPS, off-server DB backups and private storage. Public `hdprintx.in` / `app.hdprintx.in` / `api.hdprintx.in`.
- **CI/CD:** GitHub Actions build/test/security check, human-approved production deployment, migrations, smoke tests and rollback/forward-fix playbook.
- Cloudflare Tunnel is a preview/transport mechanism, **not a replacement for application authentication and authorisation**.

## 11. QA acceptance criteria

- All 88 prototypes have a corresponding implementation ticket marked `existing`, `to enhance`, `new`, or `deferred`.
- Verify desktop at 1440px, tablet at 768px, mobile at 390px and small mobile at 320px.
- Verify zero major horizontal overflow, keyboard navigation and reduced-motion fallback.
- All customer and staff read/write actions validate resource-level access on backend.
- Verify empty, loading, error and offline states, including failed external integrations.
- Automated unit/integration/E2E tests for quote version approval, upload, status transitions, payment idempotency, work assignment and split delivery.
- Don't deploy development-only owner key, sample API secrets or fake production updates to PROD.
- Performance and accessibility review before launch, including mid-range Android device testing.

## 12. What has been verified in THIS prototype

Browser-driven QA exercised **88 screens**, detected no JavaScript rendering errors, verified quote recalculation, order progression, local proof approval, QC selection, and mobile no-overflow / drawer behaviour. See `qa-browser-results.json`. This is NOT an end-to-end test of the actual Codex project or any backend.

## 13. Recommended initial Codex prompt (copy below)

> You are implementing the HDPrintX website and full print-management application in my EXISTING repository. First read `CODEX_ALL_VIEWS_HANDOFF.md`, `VIEW_INVENTORY.csv`, `README.md`, and inspect the interactive `index.html`/`styles.css`/`app.js` sample. This prototype is a visual reference, NOT a production codebase. **Do not overwrite existing Codex work.**
>
> **Step 1 — Audit only.** Inspect existing Next.js/React routing, components, layout, authentication, Java/Spring Boot modules, PostgreSQL schema and migrations, API DTOs, test suites, GitHub Actions, Docker files and Cloudflare Tunnel config. Create `docs/ux/EXISTING_VS_PROPOSED.md` mapping all 88 views to implemented, partially implemented, new or deferred. Identify visual inconsistencies, routes missing required data, security blockers and reusable components. Do not refactor application logic during the audit.
>
> **Step 2 — Design-system PR.** Implement brand tokens, typography, reusable cards/forms/buttons/tables/status indicators, shared accessible navigation shells, mobile breakpoints and reduced-motion support without breaking existing routes. Use the prototype only as a UI inspiration and compare screenshots to target designs.
>
> **Step 3 — Plan incremental releases.** Create GitHub-compatible tasks or Markdown backlog grouped by public site, customer portal, business MIS, production, vendors, delivery and system states, with acceptance criteria, API dependencies, testing, scope and screenshots.
>
> **Step 4 — Implement only first approved slice.** Start with a public homepage/products design iteration after the audit. Reuse real domain models and APIs already present. Keep mocked example data strictly in isolated DEV previews. No live production data fabricated.
>
> **Step 5 — Test and report.** Execute repository-specific lint, unit/integration and E2E tests; record screenshots at desktop/tablet/mobile; report files changed, tests passed/failed, remaining API needs and any human credentials/provisioning required. Do not claim tests or releases completed unless executed.
>
> **Constraints:** preserve database migrations and existing order records, maintain server-side RBAC, never weaken auth, keep Cloudflare Access on DEV/QA, don't introduce heavy WebGL by default, don't hardcode provider secrets, and don't send actual WhatsApp/email/payment messages from prototype paths.

