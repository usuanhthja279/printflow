from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw,ImageFont
import json,math
p=Path(__file__).parent
out=p/'screenshots'/'all';out.mkdir(parents=True,exist_ok=True)
groups=p/'screen_groups';groups.mkdir(exist_ok=True)
views=json.loads((p/'VIEW_INVENTORY.json').read_text())
html=(p/'index.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(p/'styles.css').read_text()+'</style>').replace('<script src="app.js" defer></script>','<script>'+(p/'app.js').read_text()+'</script>')
with sync_playwright() as play:
 browser=play.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1360,'height':860},device_scale_factor=1)
 page.set_content(html,wait_until='load')
 for i,v in enumerate(views):
  page.evaluate('(id)=>HDPrintXPreview.go(id)',v['id'])
  page.screenshot(path=str(out/(v['id']+'.jpg')),type='jpeg',quality=71,full_page=False,timeout=15000,animations='disabled')
  if (i+1)%15==0:print(f'Exported {i+1}/{len(views)} screenshots',flush=True)
 browser.close()
regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf';FONT=ImageFont.truetype(bold,18);SUB=ImageFont.truetype(regular,13);HEAD=ImageFont.truetype(bold,25)
gnames=list(dict.fromkeys(v['group'] for v in views))
for g in gnames:
 subset=[v for v in views if v['group']==g]
 cols=3;w=440;h=300;pad=25;header=110;cellh=355
 rows=math.ceil(len(subset)/cols)
 sheet=Image.new('RGB',(cols*w+(cols+1)*pad,header+rows*cellh+35),(11,20,39));d=ImageDraw.Draw(sheet)
 d.text((pad,23),f'HDPrintX / {g.upper()}',font=HEAD,fill='#ffffff')
 d.text((pad,66),f'{len(subset)} design screens  •  Fictional sample data / interactive reference',font=SUB,fill='#a9bddb')
 for i,v in enumerate(subset):
  x=pad+(i%cols)*(w+pad);y=header+(i//cols)*cellh
  img=Image.open(out/(v['id']+'.jpg')).convert('RGB')
  img=img.crop((240,74,img.width,img.height))
  iw,ih=img.size
  scale=min(w/iw,h/ih)
  img=img.resize((round(iw*scale),round(ih*scale)),Image.Resampling.LANCZOS)
  d.rounded_rectangle((x-3,y-3,x+w+3,y+h+3),radius=11,fill=(29,45,72))
  sheet.paste(img,(x,y))
  d.text((x,y+h+13),f'{i+1:02d}  {v["title"]}',font=FONT,fill='white')
  d.text((x,y+h+37),v['id'],font=SUB,fill='#adbdd6')
 dest=groups/(g.lower().replace(' & ','_').replace(' ','_')+'_all_views.jpg')
 sheet.save(dest,quality=85,subsampling=0)
 print('Wrote group sheet:',dest.name,flush=True)
print('Export complete')
