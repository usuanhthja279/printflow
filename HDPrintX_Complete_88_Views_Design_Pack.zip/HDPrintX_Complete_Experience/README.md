# HDPrintX — Complete Experience Lab (v2)

A **visual, click-through design prototype** covering the HDPrintX printing business across seven workspace groups and 88 individual interface views.

## Start locally

1. Extract the ZIP.
2. Double-click `index.html` in Chrome/Brave/Edge. The prototype has no external font, CSS, JS or API dependencies.
3. Use the left sidebar's searchable catalog to switch views.
4. Use the buttons on screens to navigate or trigger labelled, local-only demonstrations.

Alternative via PowerShell:

```powershell
cd .\HDPrintX_Complete_Experience
python -m http.server 3005
# Open http://localhost:3005
```

You can preview it via **Cloudflare Tunnel** for authorised collaborators, but only through the preconfigured Cloudflare Access policy. Because the prototype has fictional data and no real login, never mistake it for an access-controlled product.

## What's in this package

- `index.html` / `styles.css` / `app.js`: complete standalone interactive prototype
- `VIEW_INVENTORY.csv` and `.json`: all 88 screen IDs, group names and renderer types
- `CODEX_ALL_VIEWS_HANDOFF.md`: engineering implementation guide and master Codex prompt
- `screenshots/`: twelve representative desktop screenshots plus mobile
- `HDPrintX_12_View_Contact_Sheet.jpg`: one-glance overview of representative screens
- `concept_boards/`: three high-fidelity static concept boards (illustrations)
- `qa-browser-results.json`: browser QA summary
- `test_preview.py`: Playwright script used for QA (requires Python Playwright and Chromium)

## Working demo interactions

- Multi-view navigation (URL hash supports direct entry, e.g., `index.html#proof-viewer`)
- Search the screen catalog
- Quote product, size, quantity, paper, finish and turnaround changes affect a **demonstration estimate**
- Material-finish switching changes the product illustration
- Customer order timeline can advance/reset
- Proof approval toggles demonstration state
- QC checkboxes maintain local state
- Production progress can be simulated
- Messaging demo lets you append a local message
- Responsive small-screen navigation drawer
- Basic forms, modal previews, status and empty/error components

## Not a real application

This is a **frontend design artifact**. Nothing is sent to HDPrintX servers. It has **no real login, data persistence, PDF processing, payments, messaging APIs, fulfilment, or accurate job costing**. Simulated numbers and brand portfolio content should not be presented as facts about the company.

## Development handoff

The project already has an evolving React/Next.js and Spring Boot codebase in Codex. **Audit the existing repository first** and migrate styles/components gradually. Do not overwrite real order/business logic with demo mock state. The step-by-step process is in `CODEX_ALL_VIEWS_HANDOFF.md`.
