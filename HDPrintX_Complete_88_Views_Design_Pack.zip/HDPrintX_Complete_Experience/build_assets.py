from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw, ImageFont
import json, csv, shutil
p=Path(__file__).parent
html=(p/'index.html').read_text().replace('<link rel="stylesheet" href="styles.css">','<style>'+(p/'styles.css').read_text()+'</style>').replace('<script src="app.js" defer></script>','<script>'+(p/'app.js').read_text()+'</script>')
with sync_playwright() as sp:
 b=sp.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=b.new_page();page.set_content(html,wait_until='load')
 views=page.evaluate('HDPrintXPreview.views')
 b.close()
(p/'VIEW_INVENTORY.json').write_text(json.dumps(views,ensure_ascii=False,indent=2))
with (p/'VIEW_INVENTORY.csv').open('w',newline='',encoding='utf-8') as f:
 w=csv.DictWriter(f,fieldnames=['id','title','type','group','icon']);w.writeheader();w.writerows(views)
font_regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font_bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
if not Path(font_regular).exists():
 font_regular='/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf';font_bold='/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf'
B=ImageFont.truetype(font_bold,23);T=ImageFont.truetype(font_bold,16);S=ImageFont.truetype(font_regular,13)
select=['home','products','material-lab','quote-builder','order-tracking','customer-dashboard','owner-dashboard','production-board','inventory','proof-viewer','vendor-dashboard','delivery-dashboard']
name={v['id']:v['title'] for v in views}
W=1600; cols=3;rows=4;w=490;h=330;ox=40;oy=128
sheet=Image.new('RGB',(W,oy+rows*(h+63)+65),(10,19,36))
d=ImageDraw.Draw(sheet)
d.text((40,28),'HDPrintX  /  COMPLETE EXPERIENCE',font=B,fill='#fff')
d.text((40,70),f'{len(views)} interactive views  ·  7 workspace groups  ·  12 screen previews',font=S,fill=(169,187,210))
for i,v in enumerate(select):
 img=Image.open(p/'screenshots'/f'{v}.png').convert('RGB')
 # crop hide rail for focus
 img=img.crop((255,78,img.width,min(img.height,940)))
 iw,ih=img.size; tw=w;th=int(ih*tw/iw)
 if th>h: tw=int(tw*h/th);th=h
 img=img.resize((tw,th),Image.Resampling.LANCZOS)
 x=ox+(i%cols)*(w+25); y=oy+(i//cols)*(h+63)
 d.rounded_rectangle((x-3,y-3,x+w+3,y+h+3),radius=14,fill=(32,44,66))
 sheet.paste(img,(x,y))
 d.text((x,y+h+13),f'{i+1:02d}   {name[v]}',font=T,fill='#fff')
 d.text((x,y+h+37),next(t['group'] for t in views if t['id']==v),font=S,fill='#abc0dd')
sheet.save(p/'HDPrintX_12_View_Contact_Sheet.jpg',quality=92,subsampling=0)
print('view inventory',len(views),'contact sheet generated',sheet.size)

# copy generated design inspiration boards from current turn
board_dir=p/'concept_boards';board_dir.mkdir(exist_ok=True)
for i,name in enumerate(['wide_panoramic_collage_of_a_modern_ui_ux_design_sh.png','a_large_high_resolution_ui_ux_design_presentation.png','a_wide_clean_multi_panel_ui_ux_design_showcase_p.png'],1):
 src=Path('/mnt/data')/name
 if src.exists():shutil.copy2(src,board_dir/f'concept_board_{i}.png')
