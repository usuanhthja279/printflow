# Batch 2 correction pass

Focused corrections to the production command centre and readiness guidance. Existing role authorization, revision checks and production/payment/evidence gates remain authoritative.

## Changes

- Operator queue responses omit owner-only financial, invoice, proof and evidence readiness fields. The printer drawer does not create confirmation checks from those omitted fields, identifies owner-only checks, and shows separately permitted missing pickup evidence. The READY stage label for operators is “Production complete”; only the owner-facing dispatch checklist says “Ready for dispatch.”
- Payment stage/readiness now requires valid current payment terms before reporting paid-in-full. Owner release/dispatch advisory blockers include current terms and overpayment policy checks, alongside existing balance/credit and invoice checks. A fully paid order without valid current terms remains blocked by the existing server validation.
- HOLD is defined by an active hold reason. QC/rework attention excludes held jobs. Filter results, exception badges and counts now use those same predicates.
- Unassigned production counts and results both exclude jobs awaiting release.
- Queue refresh updates the open selected job or closes it if it is no longer present. The owner action centre can manually refresh its summary and production counts.
- Pickup-photo waiver is presented as “Waived” with its policy explanation; it is no longer described as a scanned upload.
- Production lane controls use compact horizontally scrollable chips on phones.

## Focused verification

`npm.cmd run build` passed. `npm.cmd run test:e2e -- e2e/batch2-corrections.spec.ts --project=desktop --project=mobile --max-failures=1` passed both browser projects. The focused Gradle integration test `WorkflowMailIntegrationTest.routingProductionQueueAndDeliveryPhotosRespectScopesAndGates` passed against native PostgreSQL; no Docker was used. Full visual results, commands and limitations are in `output/batch2-correction-pass/VISUAL_TEST_REPORT.md` and the screenshot gallery `output/batch2-correction-pass/index.html`.

Actual before/after browser evidence is in `output/batch2-correction-pass/before/` and `output/batch2-correction-pass/after/`. Before screenshots are from the prior Batch 2 gallery; exact fixture parity is unavailable for some scenarios and is called out in the report. New after screenshots are actual browser captures at 1440×900 and 390×844.
